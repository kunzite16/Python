import tkinter as tk
from tkinter import ttk, messagebox
import requests
import json
import os


class GitHubRepoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("GitHub Repository Info")
        self.root.geometry("500x400")

        # Создаем основной интерфейс
        self.create_widgets()

    def create_widgets(self):
        # Заголовок
        title_label = tk.Label(
            self.root,
            text="GitHub Repository Information",
            font=("Arial", 16, "bold")
        )
        title_label.pack(pady=20)

        # Метка и поле ввода для имени репозитория
        input_frame = tk.Frame(self.root)
        input_frame.pack(pady=20)

        repo_label = tk.Label(
            input_frame,
            text="Repository Name (owner/repo):",
            font=("Arial", 10)
        )
        repo_label.pack(side=tk.LEFT, padx=(0, 10))

        self.repo_entry = tk.Entry(input_frame, width=30, font=("Arial", 10))
        self.repo_entry.pack(side=tk.LEFT)
        self.repo_entry.insert(0, "kubernetes/kubernetes")

        # Кнопка для получения информации
        self.get_info_btn = tk.Button(
            self.root,
            text="Get Repository Info",
            command=self.get_repo_info,
            bg="#2ea44f",
            fg="white",
            font=("Arial", 10, "bold"),
            padx=20,
            pady=10
        )
        self.get_info_btn.pack(pady=20)

        # Область для отображения результата
        result_frame = tk.LabelFrame(self.root, text="Result", padx=10, pady=10)
        result_frame.pack(padx=20, pady=10, fill=tk.BOTH, expand=True)

        self.result_text = tk.Text(result_frame, height=10, font=("Courier", 9))
        self.result_text.pack(fill=tk.BOTH, expand=True)

        # Добавляем скроллбар
        scrollbar = tk.Scrollbar(self.result_text)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.result_text.config(yscrollcommand=scrollbar.set)
        scrollbar.config(command=self.result_text.yview)

        # Статус бар
        self.status_bar = tk.Label(
            self.root,
            text="Ready",
            bd=1,
            relief=tk.SUNKEN,
            anchor=tk.W
        )
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)

    def get_repo_info(self):
        # Получаем имя репозитория из поля ввода
        repo_name = self.repo_entry.get().strip()

        if not repo_name:
            messagebox.showerror("Error", "Please enter a repository name!")
            return

        self.status_bar.config(text="Fetching data from GitHub...")
        self.root.update()

        try:
            # Формируем URL для API GitHub
            url = f"https://api.github.com/repos/{repo_name}"

            # Делаем запрос к GitHub API
            response = requests.get(url, timeout=10)

            if response.status_code == 200:
                data = response.json()

                # Извлекаем информацию о владельце
                owner_info = data.get('owner', {})

                # Формируем результат в нужном формате
                result_data = {
                    'company': owner_info.get('company'),
                    'created_at': owner_info.get('created_at'),
                    'email': owner_info.get('email'),
                    'id': owner_info.get('id'),
                    'name': owner_info.get('login'),
                    'url': owner_info.get('url')
                }

                # Отображаем результат в текстовом поле
                self.result_text.delete(1.0, tk.END)
                formatted_json = json.dumps(result_data, indent=2, ensure_ascii=False)
                self.result_text.insert(1.0, formatted_json)

                # Сохраняем в файл
                self.save_to_file(result_data, repo_name)

                self.status_bar.config(text="Data fetched and saved successfully!")

            elif response.status_code == 404:
                messagebox.showerror("Error", "Repository not found!")
                self.status_bar.config(text="Error: Repository not found")
            else:
                messagebox.showerror("Error", f"GitHub API error: {response.status_code}")
                self.status_bar.config(text=f"Error: GitHub API returned {response.status_code}")

        except requests.exceptions.RequestException as e:
            messagebox.showerror("Error", f"Network error: {str(e)}")
            self.status_bar.config(text="Error: Network connection failed")
        except Exception as e:
            messagebox.showerror("Error", f"Unexpected error: {str(e)}")
            self.status_bar.config(text="Error: Unexpected error occurred")

    def save_to_file(self, data, repo_name):
        # Создаем имя файла на основе имени репозитория
        safe_repo_name = repo_name.replace('/', '_')
        filename = f"github_info_{safe_repo_name}.json"

        # Сохраняем данные в JSON файл
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        # Показываем сообщение об успешном сохранении
        messagebox.showinfo(
            "Success",
            f"Data has been saved to:\n{os.path.abspath(filename)}"
        )


def main():
    root = tk.Tk()
    app = GitHubRepoApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()